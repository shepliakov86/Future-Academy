Please view the following link in order to get all access details: http://rdmd.stgnew.com/johncarter/README.md
