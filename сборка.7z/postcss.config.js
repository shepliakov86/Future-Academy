module.exports = {
  plugins: {
    'postcss-preset-env': true,
  },
};
